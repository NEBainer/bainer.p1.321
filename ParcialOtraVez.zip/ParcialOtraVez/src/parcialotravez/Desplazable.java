
package parcialotravez;


public interface Desplazable {
    
    public void desplazar();
    
}
