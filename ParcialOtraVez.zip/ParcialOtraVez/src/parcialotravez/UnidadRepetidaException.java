package parcialotravez;


public class UnidadRepetidaException extends RuntimeException{

    public UnidadRepetidaException(String mensage) {
        super(mensage);
    }
    
}
