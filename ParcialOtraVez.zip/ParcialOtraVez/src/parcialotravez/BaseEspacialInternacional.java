package parcialotravez;

import java.util.ArrayList;
import java.util.List;


public class BaseEspacialInternacional{ 
    private List<UnidadOperativa> unidadesOperativas = new ArrayList<>();
    
    public void agregarUnidadOperativa(UnidadOperativa unidadAAgregar){
        if(unidadesOperativas.contains(unidadAAgregar)){
            throw new UnidadRepetidaException("Error. La unidad ingresada ya existe en el modulo en el cual se desea agregar.");
        }
        unidadesOperativas.add(unidadAAgregar);
    }
    
    public void mostrarUnidades(){
        for( UnidadOperativa unidad: unidadesOperativas){
            System.out.println(unidad);
            System.out.println("-----------");
        }
    }
    
    public void moverUnidades(){
        for( UnidadOperativa unidad: unidadesOperativas){
            if(unidad instanceof Desplazable){
                ((Desplazable)unidad).desplazar();
            }else {
                System.out.println(unidad.getNombre() +" no puede moverse debido a que no es desplazable");
            }
        }
    }
    
    public void realizarFuncionesBase(){
        for(UnidadOperativa unidad: unidadesOperativas){
            unidad.reabastecerse();
            unidad.mantenerCondicionesAtmosfericas();
            unidad.replicarse();
            System.out.println("----------");
        }
    }
    
    
    
    public List<UnidadOperativa> filtrarPorTipoAtmosfera(TipoDeAtmosfera tipo){
        List <UnidadOperativa>listaFiltrada = new ArrayList<>();
        for(UnidadOperativa unidad: unidadesOperativas){
            if(unidad.operaEnAtmosfera(tipo)){
                listaFiltrada.add(unidad);
            }
        }
        return listaFiltrada;
    }

}
