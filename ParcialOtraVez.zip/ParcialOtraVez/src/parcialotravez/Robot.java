package parcialotravez;


public class Robot extends UnidadOperativa implements Desplazable{
    private int autonomiaOperativa;

    public Robot( String nombre, String modulo, TipoDeAtmosfera tipoDeAtmosfera, int autonomiaOperativa) {
        super(nombre, modulo, tipoDeAtmosfera);
        this.autonomiaOperativa = autonomiaOperativa;
    }

    public int getAutonomiaOperativa() {
        return autonomiaOperativa;
    }

    @Override
    public void desplazar(){
        System.out.println("El robot " + getNombre() +" se desplaza a otro modulo moviendo sus piezas de metal");
    }
    
    @Override
    public void reabastecerse(){
        System.out.println("El robot " + getNombre() +" se reabastece de electricidad para seguir funcionando");
    }
    
    @Override
    public void mantenerCondicionesAtmosfericas(){
        System.out.println("El robot " + getNombre()+ " mantiene las condiciones ideales de atmosfera disminuyendo levemente la presion de su lugar de trabajo");
    }
    
    @Override
    public void replicarse(){
        System.out.println("El robot " + getNombre() +" se replica copiando sus datos en la computadora maestra");
    }
    
    @Override
    public String toString(){
        return super.toString()+ "\nCantidad de horas de autonomia operativa: " + autonomiaOperativa;
    }

}
