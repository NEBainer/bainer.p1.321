package parcialotravez;


public class Astronauta extends UnidadOperativa implements Desplazable{
    private int cantMaxHorasEVA;

    public Astronauta(String nombre, String modulo, TipoDeAtmosfera tipoDeAtmosfera, int cantMaxHorasEVA) {
        super(nombre, modulo, tipoDeAtmosfera);
        this.cantMaxHorasEVA = cantMaxHorasEVA;
    }

    public int getCantMaxHorasEVA() {
        return cantMaxHorasEVA;
    }
    
    @Override
    public void desplazar(){
        System.out.println("El astronauta " + getNombre() +" se desplaza a otro modulo dando brincos");
    }
    
    @Override
    public void reabastecerse(){
        System.out.println("El astronauta " + getNombre() +" se reabastece de oxigeno para su traje");
    }
    
    @Override
    public void mantenerCondicionesAtmosfericas(){
        System.out.println("El astronauta " + getNombre()+ " mantiene las condiciones ideales de atmosfera despresurizando su nave");
    }
    
    @Override
    public void replicarse(){
        System.out.println("El astronauta " + getNombre() +" se replica entrenando duro con otros astronautas");
    }
    
    @Override
    public String toString(){
        return super.toString()+ "\nCantidad maxima de horas EVA: " + cantMaxHorasEVA;
    }

}
