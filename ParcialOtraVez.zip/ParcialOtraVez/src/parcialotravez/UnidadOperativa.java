package parcialotravez;

import java.util.Objects;


public abstract class UnidadOperativa{
    private String nombre;
    private String modulo;
    private TipoDeAtmosfera tipoDeAtmosfera;

    public UnidadOperativa(String nombre, String modulo, TipoDeAtmosfera tipoDeAtmosfera) {
        this.nombre = nombre;
        this.modulo = modulo;
        this.tipoDeAtmosfera = tipoDeAtmosfera;
    }

    public String getNombre() {
        return nombre;
    }

    public String getModulo() {
        return modulo;
    }

    public TipoDeAtmosfera getTipoDeAtmosfera() {
        return tipoDeAtmosfera;
    }
    
    public boolean operaEnAtmosfera(TipoDeAtmosfera tipo){
        return (tipoDeAtmosfera == tipo);
    }
    
    public abstract void reabastecerse();
    
    public abstract void mantenerCondicionesAtmosfericas();
    
    public abstract void replicarse();

    @Override
    public String toString() {
        return  "Nombre: " + nombre + "\nmodulo: "+ modulo + "\ntipoAtmosfera: " + tipoDeAtmosfera;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        UnidadOperativa otra = (UnidadOperativa) obj;
        return nombre.equals(otra.nombre) && modulo.equals(otra.modulo);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(nombre, modulo);
    }
}
    
    

