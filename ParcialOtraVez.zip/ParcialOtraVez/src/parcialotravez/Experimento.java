package parcialotravez;


public class Experimento extends UnidadOperativa{
    private int duracionIdeal;

    public Experimento(String nombre, String modulo, TipoDeAtmosfera tipoDeAtmosfera, int duracionIdeal) {
        super(nombre, modulo, tipoDeAtmosfera);
        this.duracionIdeal = duracionIdeal;
    }

    public int getDuracionIdeal() {
        return duracionIdeal;
    }
    
    @Override
    public void reabastecerse(){
        System.out.println("El experimento " + getNombre() +" se reabastece controlando sus signos vitales y llenando su tanque de fluidos");
    }
    
    @Override
    public void mantenerCondicionesAtmosfericas(){
        System.out.println("El experimento " + getNombre()+ " mantiene las condiciones ideales de atmosfera disminuyendo la presion en su laboratorio");
    }
    
    @Override
    public void replicarse(){
        System.out.println("El experimento " + getNombre() +" se replica activando su protocolo de clonacion");
    }
    
    @Override
    public String toString(){
        return super.toString()+ "\nCantidad de dias de duracion ideal: " + duracionIdeal;
    }
}
