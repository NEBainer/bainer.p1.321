
package parcialotravez;

import java.util.List;


public class ParcialOtraVez {


    public static void main(String[] args) {
        BaseEspacialInternacional base1 = new BaseEspacialInternacional();
        cargarBaseEspacial(base1);
        
        System.out.println("\n--- Unidades registradas ---");
        base1.mostrarUnidades();
        
        System.out.println("\n--- Movimiento de unidades ---");
        base1.moverUnidades();
        
        System.out.println("\n--- Funciones base ---");
        base1.realizarFuncionesBase();
        
        System.out.println("\n--- Filtrar por tipo de atmosfera ---");
        List<UnidadOperativa> filtradas = base1.filtrarPorTipoAtmosfera(TipoDeAtmosfera.PRESURIZADA);
        if (filtradas.isEmpty()) {
            System.out.println("No hay unidades en la atmosfera seleccionada");
        } else {
            System.out.println("Unidades en la atmósfera filtrada:");
            for (UnidadOperativa u : filtradas) {
                System.out.println(u);
            }
        }
    }
    
    public static void cargarBaseEspacial(BaseEspacialInternacional baseACargar){
        try{
            baseACargar.agregarUnidadOperativa(new Astronauta("Jorge", "m1", TipoDeAtmosfera.VACIO, 10));
            baseACargar.agregarUnidadOperativa(new Robot("R2D2", "m2", TipoDeAtmosfera.VACIO, 10));
            baseACargar.agregarUnidadOperativa(new Experimento("Cloncito", "m3", TipoDeAtmosfera.VACIO, 22));
            baseACargar.agregarUnidadOperativa(new Astronauta("Jorge", "m1", TipoDeAtmosfera.VACIO, 12));
            
        }
        
        catch(UnidadRepetidaException e){
            System.out.println("Error: "+ e.getMessage());
        }
        
    }
    
}
