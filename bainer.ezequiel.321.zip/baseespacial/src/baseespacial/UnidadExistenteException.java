package baseespacial;

public class UnidadExistenteException extends RuntimeException {
    public UnidadExistenteException(String mensaje) {
        super(mensaje);
    }
}
