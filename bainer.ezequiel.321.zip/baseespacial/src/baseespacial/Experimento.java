package baseespacial;

public class Experimento extends UnidadOperativa {
    private int duracionIdealDias;

    public Experimento(String nombre, String modulo, TipoAtmosfera tipoAtmosfera, int duracionIdealDias) {
        super(nombre, modulo, tipoAtmosfera);
        this.duracionIdealDias = duracionIdealDias;
    }

    @Override
    public void replicarse() {
        System.out.println(getNombre() + " replica su protocolo experimental.");
    }

    @Override
    public String getDetalles() {
        return "Duracion ideal: " + duracionIdealDias + " dias";
    }
}
