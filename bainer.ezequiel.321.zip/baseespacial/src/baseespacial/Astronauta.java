package baseespacial;

public class Astronauta extends UnidadOperativa implements Movible {
    private int horasMaxEVA;

    public Astronauta(String nombre, String modulo, TipoAtmosfera tipoAtmosfera, int horasMaxEVA) {
        super(nombre, modulo, tipoAtmosfera);
        this.horasMaxEVA = horasMaxEVA;
    }

    @Override
    public void replicarse() {
        System.out.println(getNombre() + " entrena a un nuevo astronauta.");
    }

    @Override
    public void mover() {
        System.out.println(getNombre() + " se desplaza a otro modulo.");
    }

    @Override
    public String getDetalles() {
        return "Horas max. EVA: " + horasMaxEVA;
    }
}
