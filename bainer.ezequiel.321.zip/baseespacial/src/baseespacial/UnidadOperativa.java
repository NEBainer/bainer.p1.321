package baseespacial;

public abstract class UnidadOperativa {
    private String nombre;
    private String modulo;
    private TipoAtmosfera tipoAtmosfera;

    public UnidadOperativa(String nombre, String modulo, TipoAtmosfera tipoAtmosfera) {
        this.nombre = nombre;
        this.modulo = modulo;
        this.tipoAtmosfera = tipoAtmosfera;
    }

    public String getNombre() {
        return nombre;
    }

    public String getModulo() {
        return modulo;
    }

    public TipoAtmosfera getTipoAtmosfera() {
        return tipoAtmosfera;
    }

    public void reabastecer() {
        System.out.println(nombre + " se esta reabasteciendo.");
    }

    public void mantenerAtmosfera() {
        System.out.println(nombre + " mantiene las condiciones atmosfericas adecuadas.");
    }

    public abstract void replicarse();

    public abstract String getDetalles();

    @Override
    public String toString() {
        return nombre + " - Modulo: " + modulo + " - Atmosfera: " + tipoAtmosfera + " - " + getDetalles();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        UnidadOperativa otra = (UnidadOperativa) obj;
        return nombre.equals(otra.nombre) && modulo.equals(otra.modulo);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(nombre, modulo);
    }
}
