/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package baseespacial;

/**
 *
 * @author ezzeb
 */
public class Baseespacial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BaseEspacialInternacional base = new BaseEspacialInternacional();

        try {
            base.agregarUnidadOperativa(new Astronauta("John", "Modulo 1", TipoAtmosfera.PRESURIZADA, 8));
            base.agregarUnidadOperativa(new Robot("R2-D2", "Modulo 2", TipoAtmosfera.VACIO, 12));
            base.agregarUnidadOperativa(new Experimento("Fotosintesis Lunar", "Modulo 3", TipoAtmosfera.PRESURIZADA, 15));

            //Intento duplicado para comprobar el funcionamiento de la Exception
            base.agregarUnidadOperativa(new Astronauta("John", "Modulo 1", TipoAtmosfera.PRESURIZADA, 8));

        } catch (UnidadExistenteException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("\n--- Unidades registradas ---");
        base.mostrarUnidades();

        System.out.println("\n--- Movimiento de unidades ---");
        base.moverUnidades();

        System.out.println("\n--- Funciones base ---");
        base.realizarFuncionesBase();

        System.out.println("\n--- Filtrado por atmosfera ---");
        base.filtrarPorTipoAtmosfera(TipoAtmosfera.PRESURIZADA);
    }
    
}
