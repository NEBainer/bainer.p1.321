package baseespacial;

import java.util.ArrayList;
import java.util.List;

public class BaseEspacialInternacional {
    private List<UnidadOperativa> unidades;

    public BaseEspacialInternacional() {
        unidades = new ArrayList<>();
    }

    public void agregarUnidadOperativa(UnidadOperativa u) {
        if (unidades.contains(u)) {
            throw new UnidadExistenteException("Ya existe una unidad con ese nombre en ese modulo.");
        }
        unidades.add(u);
    }

    public void mostrarUnidades() {
        if (unidades.isEmpty()) {
            System.out.println("No hay unidades registradas.");
        }
        for (UnidadOperativa u : unidades) {
            System.out.println(u);
        }
    }

    public void moverUnidades() {
        for (UnidadOperativa u : unidades) {
            if (u instanceof Movible) {
                ((Movible) u).mover();
            } else {
                System.out.println(u.getNombre() + " no puede moverse (experimento fijo).");
            }
        }
    }

    public void realizarFuncionesBase() {
        for (UnidadOperativa u : unidades) {
            u.reabastecer();
            u.mantenerAtmosfera();
            u.replicarse();
        }
    }

    public List<UnidadOperativa> filtrarPorTipoAtmosfera(TipoAtmosfera tipo) {
        List<UnidadOperativa> resultado = new ArrayList<>();
        for (UnidadOperativa u : unidades) {
            if (u.getTipoAtmosfera() == tipo) {
                resultado.add(u);
            }
        }

        if (resultado.isEmpty()) {
            System.out.println("No hay unidades en atmosfera " + tipo);
        } else {
            System.out.println("Unidades en atmosfera " + tipo + ":");
            for (UnidadOperativa u : resultado) {
                System.out.println(u);
            }
        }

        return resultado;
    }
}
