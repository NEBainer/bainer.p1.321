package baseespacial;

public class Robot extends UnidadOperativa implements Movible {
    private int autonomiaHoras;

    public Robot(String nombre, String modulo, TipoAtmosfera tipoAtmosfera, int autonomiaHoras) {
        super(nombre, modulo, tipoAtmosfera);
        this.autonomiaHoras = autonomiaHoras;
    }

    @Override
    public void replicarse() {
        System.out.println(getNombre() + " clona su protocolo de funcionamiento.");
    }

    @Override
    public void mover() {
        System.out.println(getNombre() + " se desplaza mecanicamente a otro modulo.");
    }

    @Override
    public String getDetalles() {
        return "Autonomia: " + autonomiaHoras + " h";
    }
}
